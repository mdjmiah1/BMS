<?php
// In meta-boxes.php

function bms_add_book_meta_box() {
    add_meta_box(
        'bms_book_details',            // Unique ID
        'Book Details',                // Box title
        'bms_display_book_meta_box',    // Content callback, must be of type callable
        'book',                        // Post type
        'normal',                      // Context (normal, side, etc.)
        'high'                         // Priority
    );
}
add_action('add_meta_boxes', 'bms_add_book_meta_box');

// Callback function to display fields in the meta box
function bms_display_book_meta_box($post) {
    // Retrieve existing values
    $isbn = get_post_meta($post->ID, '_bms_book_isbn', true);
    $publisher = get_post_meta($post->ID, '_bms_book_publisher', true);
    $author = get_post_meta($post->ID, '_bms_book_author', true);
    $page_count = get_post_meta($post->ID, '_bms_book_page_count', true);
    $publish_date = get_post_meta($post->ID, '_bms_book_publish_date', true);
    $file_size = get_post_meta($post->ID, '_bms_book_file_size', true);
    $url = get_post_meta($post->ID, '_bms_book_url', true);
    $archive = get_post_meta($post->ID, '_bms_book_archive', true);

    // Output fields
    ?>
    <div id="bms_book_details">
        <div class="form-row">
            <div class="form-item">
                <label for="bms_book_author">Author</label>
                <input type="text" id="bms_book_author" name="bms_book_author" value="<?php echo esc_attr($author); ?>" />
            </div>
            <div class="form-item">
                <label for="bms_book_publisher">Publisher</label>
                <input type="text" id="bms_book_publisher" name="bms_book_publisher" value="<?php echo esc_attr($publisher); ?>" />
            </div>
            <div class="form-item">
                <label for="bms_book_publish_date">Publish Date</label>
                <input type="date" id="bms_book_publish_date" name="bms_book_publish_date" value="<?php echo esc_attr($publish_date); ?>" />
            </div>
            <div class="form-item">
                <label for="bms_book_page_count">Page Count</label>
                <input type="number" id="bms_book_page_count" name="bms_book_page_count" value="<?php echo esc_attr($page_count); ?>" />
            </div>
            <div class="form-item">
                <label for="bms_book_isbn">ISBN</label>
                <input type="text" id="bms_book_isbn" name="bms_book_isbn" value="<?php echo esc_attr($isbn); ?>" />
            </div>
            <div class="form-item">
                <label for="bms_book_file_size">File Size (MB)</label>
                <input type="text" id="bms_book_file_size" name="bms_book_file_size" value="<?php echo esc_attr($file_size); ?>" />
            </div>
            <div class="form-item">
                <label for="bms_book_url">URL</label>
                <input type="url" id="bms_book_url" name="bms_book_url" value="<?php echo esc_attr($url); ?>" />
            </div>
            <div class="form-item">
                <label for="bms_book_archive">Archive</label>
                <input type="text" id="bms_book_archive" name="bms_book_archive" value="<?php echo esc_attr($archive); ?>" />
            </div>
        </div>
    </div>
    <?php
}

// Save the meta box data, but only if fields are not empty
function bms_save_book_meta_box_data($post_id) {
    // Check nonce, autosave, user permissions, etc.

    // Check and save ISBN
    if (!empty($_POST['bms_book_isbn'])) {
        update_post_meta($post_id, '_bms_book_isbn', sanitize_text_field($_POST['bms_book_isbn']));
    } else {
        delete_post_meta($post_id, '_bms_book_isbn');
    }

    // Check and save publisher
    if (!empty($_POST['bms_book_publisher'])) {
        update_post_meta($post_id, '_bms_book_publisher', sanitize_text_field($_POST['bms_book_publisher']));
    } else {
        delete_post_meta($post_id, '_bms_book_publisher');
    }

    // Check and save author
    if (!empty($_POST['bms_book_author'])) {
        update_post_meta($post_id, '_bms_book_author', sanitize_text_field($_POST['bms_book_author']));
    } else {
        delete_post_meta($post_id, '_bms_book_author');
    }

    // Check and save page count
    if (!empty($_POST['bms_book_page_count'])) {
        update_post_meta($post_id, '_bms_book_page_count', intval($_POST['bms_book_page_count']));
    } else {
        delete_post_meta($post_id, '_bms_book_page_count');
    }

    // Check and save publish date
    if (!empty($_POST['bms_book_publish_date'])) {
        update_post_meta($post_id, '_bms_book_publish_date', sanitize_text_field($_POST['bms_book_publish_date']));
    } else {
        delete_post_meta($post_id, '_bms_book_publish_date');
    }

    // Check and save file size
    if (!empty($_POST['bms_book_file_size'])) {
        update_post_meta($post_id, '_bms_book_file_size', sanitize_text_field($_POST['bms_book_file_size']));
    } else {
        delete_post_meta($post_id, '_bms_book_file_size');
    }

    // Check and save URL
    if (!empty($_POST['bms_book_url'])) {
        update_post_meta($post_id, '_bms_book_url', esc_url($_POST['bms_book_url']));
    } else {
        delete_post_meta($post_id, '_bms_book_url');
    }

    // Check and save archive
    if (!empty($_POST['bms_book_archive'])) {
        update_post_meta($post_id, '_bms_book_archive', sanitize_text_field($_POST['bms_book_archive']));
    } else {
        delete_post_meta($post_id, '_bms_book_archive');
    }
}
add_action('save_post', 'bms_save_book_meta_box_data');




function bms_add_custom_meta_boxes() {
    add_meta_box('chapter_book_meta_box', 'Associate Book', 'bms_display_chapter_book_meta_box', 'chapter', 'side', 'default');
    add_meta_box('topic_chapter_meta_box', 'Associate Chapter', 'bms_display_topic_chapter_meta_box', 'topic', 'side', 'default');
    add_meta_box('topic_book_meta_box', 'Associate Book', 'bms_display_topic_book_meta_box', 'topic', 'side', 'default');
}

function bms_display_chapter_book_meta_box($post) {
    $books = get_posts(array('post_type' => 'book', 'numberposts' => -1));
    $selected_book = get_post_meta($post->ID, '_associated_book', true);
    
    echo '<select name="associated_book" class="bms-select2" style="width:100%;">';
    echo '<option value="">Select a book</option>';
    foreach ($books as $book) {
        $selected = ($selected_book == $book->ID) ? 'selected="selected"' : '';
        echo '<option value="' . $book->ID . '" ' . $selected . '>' . $book->post_title . '</option>';
    }
    echo '</select>';
}

function bms_display_topic_chapter_meta_box($post) {
    $chapters = get_posts(array('post_type' => 'chapter', 'numberposts' => -1));
    $selected_chapter = get_post_meta($post->ID, '_associated_chapter', true);
    
    echo '<select name="associated_chapter" class="bms-select2" style="width:100%;">';
    echo '<option value="">Select a chapter</option>';
    foreach ($chapters as $chapter) {
        $selected = ($selected_chapter == $chapter->ID) ? 'selected="selected"' : '';
        echo '<option value="' . $chapter->ID . '" ' . $selected . '>' . $chapter->post_title . '</option>';
    }
    echo '</select>';
}

function bms_display_topic_book_meta_box($post) {
    $books = get_posts(array('post_type' => 'book', 'numberposts' => -1));
    $selected_book = get_post_meta($post->ID, '_associated_book_for_topic', true);

    echo '<select name="associated_book_for_topic" class="bms-select2" style="width:100%;">';
    echo '<option value="">Select a book</option>';
    foreach ($books as $book) {
        $selected = ($selected_book == $book->ID) ? 'selected="selected"' : '';
        echo '<option value="' . $book->ID . '" ' . $selected . '>' . $book->post_title . '</option>';
    }
    echo '</select>';
}

function bms_save_custom_meta_boxes($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    if (isset($_POST['associated_book'])) {
        update_post_meta($post_id, '_associated_book', sanitize_text_field($_POST['associated_book']));
    }

    if (isset($_POST['associated_chapter'])) {
        update_post_meta($post_id, '_associated_chapter', sanitize_text_field($_POST['associated_chapter']));
    }

    if (isset($_POST['associated_book_for_topic'])) {
        update_post_meta($post_id, '_associated_book_for_topic', sanitize_text_field($_POST['associated_book_for_topic']));
    }
}

// Hook to add custom meta boxes for question post type
function bms_add_custom_meta_boxes_for_questions() {
    add_meta_box('question_book_meta_box', 'Associate Book', 'bms_display_question_book_meta_box', 'question', 'side', 'default');
    add_meta_box('question_chapter_meta_box', 'Associate Chapter', 'bms_display_question_chapter_meta_box', 'question', 'side', 'default');
    add_meta_box('question_topic_meta_box', 'Associate Topic', 'bms_display_question_topic_meta_box', 'question', 'side', 'default');
}
add_action('add_meta_boxes', 'bms_add_custom_meta_boxes_for_questions');

// Display the meta box for associating a book with a question
function bms_display_question_book_meta_box($post) {
    $books = get_posts(array('post_type' => 'book', 'numberposts' => -1));
    $selected_book = get_post_meta($post->ID, '_associated_book_for_question', true);

    echo '<select name="associated_book_for_question" class="bms-select2" style="width:100%;">';
    echo '<option value="">Select a book</option>';
    foreach ($books as $book) {
        $selected = ($selected_book == $book->ID) ? 'selected="selected"' : '';
        echo '<option value="' . $book->ID . '" ' . $selected . '>' . $book->post_title . '</option>';
    }
    echo '</select>';
}

// Display the meta box for associating a chapter with a question
function bms_display_question_chapter_meta_box($post) {
    $chapters = get_posts(array('post_type' => 'chapter', 'numberposts' => -1));
    $selected_chapter = get_post_meta($post->ID, '_associated_chapter_for_question', true);

    echo '<select name="associated_chapter_for_question" class="bms-select2" style="width:100%;">';
    echo '<option value="">Select a chapter</option>';
    foreach ($chapters as $chapter) {
        $selected = ($selected_chapter == $chapter->ID) ? 'selected="selected"' : '';
        echo '<option value="' . $chapter->ID . '" ' . $selected . '>' . $chapter->post_title . '</option>';
    }
    echo '</select>';
}

// Display the meta box for associating a topic with a question
function bms_display_question_topic_meta_box($post) {
    $topics = get_posts(array('post_type' => 'topic', 'numberposts' => -1));
    $selected_topic = get_post_meta($post->ID, '_associated_topic_for_question', true);

    echo '<select name="associated_topic_for_question" class="bms-select2" style="width:100%;">';
    echo '<option value="">Select a topic</option>';
    foreach ($topics as $topic) {
        $selected = ($selected_topic == $topic->ID) ? 'selected="selected"' : '';
        echo '<option value="' . $topic->ID . '" ' . $selected . '>' . $topic->post_title . '</option>';
    }
    echo '</select>';
}

// Save the custom metabox data
function bms_save_custom_meta_boxes_for_question($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;

    // Save associated book for the question
    if (isset($_POST['associated_book_for_question'])) {
        update_post_meta($post_id, '_associated_book_for_question', sanitize_text_field($_POST['associated_book_for_question']));
    }

    // Save associated chapter for the question
    if (isset($_POST['associated_chapter_for_question'])) {
        update_post_meta($post_id, '_associated_chapter_for_question', sanitize_text_field($_POST['associated_chapter_for_question']));
    }

    // Save associated topic for the question
    if (isset($_POST['associated_topic_for_question'])) {
        update_post_meta($post_id, '_associated_topic_for_question', sanitize_text_field($_POST['associated_topic_for_question']));
    }
}
add_action('save_post', 'bms_save_custom_meta_boxes_for_question');
