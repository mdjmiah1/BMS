<?php
// Topic
function bms_add_topic_columns($columns) {
    $columns['associated_chapter'] = 'Associated Chapter';
    $columns['associated_book'] = 'Associated Book';
    return $columns;
}
add_filter('manage_topic_posts_columns', 'bms_add_topic_columns');

function bms_display_topic_column_data($column, $post_id) {
    if ($column == 'associated_chapter') {
        $chapter_id = get_post_meta($post_id, '_associated_chapter', true);
        if ($chapter_id) {
            $chapter = get_post($chapter_id);
            echo '<a href="' . get_edit_post_link($chapter_id) . '">' . esc_html($chapter->post_title) . '</a>';
        } else {
            echo '—';
        }
    }

    if ($column == 'associated_book') {
        $book_id = get_post_meta($post_id, '_associated_book_for_topic', true);
        if ($book_id) {
            $book = get_post($book_id);
            echo '<a href="' . get_edit_post_link($book_id) . '">' . esc_html($book->post_title) . '</a>';
        } else {
            echo '—';
        }
    }
}
add_action('manage_topic_posts_custom_column', 'bms_display_topic_column_data', 10, 2);

// Chapter
function bms_add_chapter_columns($columns) {
    $columns['associated_book'] = 'Associated Book';
    $columns['associated_topics'] = 'Associated Topics';
    return $columns;
}
add_filter('manage_chapter_posts_columns', 'bms_add_chapter_columns');

function bms_display_chapter_column_data($column, $post_id) {
    if ($column == 'associated_book') {
        $book_id = get_post_meta($post_id, '_associated_book', true);
        if ($book_id) {
            $book = get_post($book_id);
            echo '<a href="' . get_edit_post_link($book_id) . '">' . esc_html($book->post_title) . '</a>';
        } else {
            echo '—';
        }
    }

    if ($column == 'associated_topics') {
        $topics = get_posts(array(
            'post_type' => 'topic',
            'meta_key' => '_associated_chapter',
            'meta_value' => $post_id,
            'numberposts' => -1
        ));
        
        if ($topics) {
            foreach ($topics as $topic) {
                echo '<a href="' . get_edit_post_link($topic->ID) . '">' . esc_html($topic->post_title) . '</a><br>';
            }
        } else {
            echo '—';
        }
    }
}
add_action('manage_chapter_posts_custom_column', 'bms_display_chapter_column_data', 10, 2);

// Book
function bms_add_book_columns($columns) {
    $columns['associated_chapters'] = 'Associated Chapters';
    $columns['associated_topics'] = 'Associated Topics';
    return $columns;
}
add_filter('manage_book_posts_columns', 'bms_add_book_columns');

function bms_display_book_column_data($column, $post_id) {
    if ($column == 'associated_chapters') {
        $chapters = get_posts(array(
            'post_type' => 'chapter',
            'meta_key' => '_associated_book',
            'meta_value' => $post_id,
            'numberposts' => -1
        ));

        if ($chapters) {
            foreach ($chapters as $chapter) {
                echo '<a href="' . get_edit_post_link($chapter->ID) . '">' . esc_html($chapter->post_title) . '</a><br>';
            }
        } else {
            echo '—';
        }
    }

    if ($column == 'associated_topics') {
        $chapters = get_posts(array(
            'post_type' => 'chapter',
            'meta_key' => '_associated_book',
            'meta_value' => $post_id,
            'numberposts' => -1
        ));
        
        if ($chapters) {
            $topics = get_posts(array(
                'post_type' => 'topic',
                'meta_query' => array(
                    array(
                        'key' => '_associated_chapter',
                        'value' => wp_list_pluck($chapters, 'ID'),
                        'compare' => 'IN',
                    )
                ),
                'numberposts' => -1
            ));

            if ($topics) {
                foreach ($topics as $topic) {
                    echo '<a href="' . get_edit_post_link($topic->ID) . '">' . esc_html($topic->post_title) . '</a><br>';
                }
            } else {
                echo '—';
            }
        } else {
            echo '—';
        }
    }
}
add_action('manage_book_posts_custom_column', 'bms_display_book_column_data', 10, 2);

// Question
function bms_add_question_columns($columns) {
    $columns['associated_book'] = 'Associated Book';
    $columns['associated_chapter'] = 'Associated Chapter';
    $columns['associated_topic'] = 'Associated Topic';
    return $columns;
}
add_filter('manage_question_posts_columns', 'bms_add_question_columns');

function bms_display_question_column_data($column, $post_id) {
    if ($column == 'associated_book') {
        $book_id = get_post_meta($post_id, '_associated_book_for_question', true);
        if ($book_id) {
            $book = get_post($book_id);
            echo '<a href="' . get_edit_post_link($book_id) . '">' . esc_html($book->post_title) . '</a>';
        } else {
            echo '—';
        }
    }

    if ($column == 'associated_chapter') {
        $chapter_id = get_post_meta($post_id, '_associated_chapter_for_question', true);
        if ($chapter_id) {
            $chapter = get_post($chapter_id);
            echo '<a href="' . get_edit_post_link($chapter_id) . '">' . esc_html($chapter->post_title) . '</a>';
        } else {
            echo '—';
        }
    }

    if ($column == 'associated_topic') {
        $topic_id = get_post_meta($post_id, '_associated_topic_for_question', true);
        if ($topic_id) {
            $topic = get_post($topic_id);
            echo '<a href="' . get_edit_post_link($topic_id) . '">' . esc_html($topic->post_title) . '</a>';
        } else {
            echo '—';
        }
    }
}
add_action('manage_question_posts_custom_column', 'bms_display_question_column_data', 10, 2);
