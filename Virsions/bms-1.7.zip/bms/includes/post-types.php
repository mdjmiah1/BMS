<?php
function bms_register_custom_post_types() {
    // Register Book Post Type
    register_post_type('book', array(
        'label' => 'Books',
        'public' => true,
        'has_archive' => true,
        'supports' => array('title', 'editor', 'excerpt', 'thumbnail'),
        'hierarchical' => true,
    ));





    // Register Chapter Post Type
    register_post_type('chapter', array(
        'label' => 'Chapters',
        'public' => true,
        'supports' => array('title', 'editor', 'comments'),
        'hierarchical' => false,
    ));

    // Register Topic Post Type
    register_post_type('topic', array(
        'label' => 'Topics',
        'public' => true,
        'supports' => array('title', 'editor', 'comments'),
        'hierarchical' => false,
    ));
    
    
    // Register Question Post Type
    register_post_type('question', array(
        'label' => 'Questions',
        'public' => true,
        'supports' => array('title', 'editor', 'comments'),
        'hierarchical' => false,
    ));
}
