<?php
// Hook to add the admin menu
function bms_add_admin_menu() {
    // Add top-level menu
    add_menu_page(
        'Book Management', // Page title
        'BMS', // Menu title
        'manage_options', // Capability
        'bms', // Menu slug
        'bms_display_admin_dashboard', // Function to display content
        'dashicons-book', // Icon
        6 // Position
    );

    // Add submenu pages
    add_submenu_page(
        'bms',
        'Books',
        'Books',
        'manage_options',
        'edit.php?post_type=book'
    );

    add_submenu_page(
        'bms',
        'Add New Book',
        'Add New Book',
        'manage_options',
        'post-new.php?post_type=book'
    );

    add_submenu_page(
        'bms',
        'Chapters',
        'Chapters',
        'manage_options',
        'edit.php?post_type=chapter'
    );

    add_submenu_page(
        'bms',
        'Add New Chapter',
        'Add New Chapter',
        'manage_options',
        'post-new.php?post_type=chapter'
    );

    add_submenu_page(
        'bms',
        'Topics',
        'Topics',
        'manage_options',
        'edit.php?post_type=topic'
    );

    add_submenu_page(
        'book-management',
        'Add New Topic',
        'Add New Topic',
        'manage_options',
        'post-new.php?post_type=topic'
    );
    
    add_submenu_page(
        'bms',
        'Question',
        'Question',
        'manage_options',
        'edit.php?post_type=question'
    );

    add_submenu_page(
        'book-management',
        'Add New Question',
        'Add New Question',
        'manage_options',
        'post-new.php?post_type=question'
    );
    add_submenu_page(
        'bms',                   // Parent slug
        'Import Books',         // Page title
        'Import Books',         // Menu title
        'manage_options',       // Capability
        'bms-import-books',     // Menu slug
        'bms_display_import_form' // Function to display content
    );
    
    
}
// Add hooks
add_action('admin_menu', 'bms_add_admin_menu');
add_action('admin_init', 'bms_import_books');
// Display the admin dashboard
// Display the admin dashboard
function bms_display_admin_dashboard() {
    // Query for books (limit to 10)
    $books = get_posts(array(
        'post_type' => 'book',
        'numberposts' => 10,  // Limit to 10 posts
        'post_status' => 'publish',
        'orderby' => 'title', // Optional: Order by title
        'order' => 'ASC'      // Optional: Ascending order
    ));

    // Query for chapters (limit to 10)
    $chapters = get_posts(array(
        'post_type' => 'chapter',
        'numberposts' => 10,  // Limit to 10 posts
        'post_status' => 'publish',
        'orderby' => 'title', // Optional: Order by title
        'order' => 'ASC'      // Optional: Ascending order
    ));

    // Query for topics (limit to 10)
    $topics = get_posts(array(
        'post_type' => 'topic',
        'numberposts' => 10,  // Limit to 10 posts
        'post_status' => 'publish',
        'orderby' => 'title', // Optional: Order by title
        'order' => 'ASC'      // Optional: Ascending order
    ));

    // Query for questions (limit to 10)
    $questions = get_posts(array(
        'post_type' => 'question',
        'numberposts' => 10,  // Limit to 10 posts
        'post_status' => 'publish',
        'orderby' => 'title', // Optional: Order by title
        'order' => 'ASC'      // Optional: Ascending order
    ));
    ?>
    <div class="wrap">
        <h1><i class="dashicons dashicons-book"></i> Book Management System Dashboard</h1>
        <p>Welcome to the Book Management System. From here, you can manage your books, chapters, topics, and questions.</p>

        <div class="bms-dashboard-cards">
            <div class="bms-card">
                <h2><i class="dashicons dashicons-book"></i> Books</h2>
                <p>Manage all your books in one place.</p>
                <a href="<?php echo admin_url('edit.php?post_type=book'); ?>" class="button button-primary">Manage Books</a>
                <a href="<?php echo admin_url('post-new.php?post_type=book'); ?>" class="button">Add New Book</a>

                <h3>Books List</h3>
                <?php if (!empty($books)): ?>
                    <table class="widefat fixed">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($books as $book): ?>
                                <tr>
                                    <td><?php echo $book->ID; ?></td>
                                    <td><?php echo esc_html($book->post_title); ?></td>
                                    <td><a href="<?php echo get_edit_post_link($book->ID); ?>">Edit</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No books found.</p>
                <?php endif; ?>
            </div>

            <div class="bms-card">
                <h2><i class="dashicons dashicons-welcome-write-blog"></i> Chapters</h2>
                <p>Manage the chapters associated with your books.</p>
                <a href="<?php echo admin_url('edit.php?post_type=chapter'); ?>" class="button button-primary">Manage Chapters</a>
                <a href="<?php echo admin_url('post-new.php?post_type=chapter'); ?>" class="button">Add New Chapter</a>

                <h3>Chapters List</h3>
                <?php if (!empty($chapters)): ?>
                    <table class="widefat fixed">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($chapters as $chapter): ?>
                                <tr>
                                    <td><?php echo $chapter->ID; ?></td>
                                    <td><?php echo esc_html($chapter->post_title); ?></td>
                                    <td><a href="<?php echo get_edit_post_link($chapter->ID); ?>">Edit</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No chapters found.</p>
                <?php endif; ?>
            </div>

            <div class="bms-card">
                <h2><i class="dashicons dashicons-edit"></i> Topics</h2>
                <p>Manage topics under your chapters.</p>
                <a href="<?php echo admin_url('edit.php?post_type=topic'); ?>" class="button button-primary">Manage Topics</a>
                <a href="<?php echo admin_url('post-new.php?post_type=topic'); ?>" class="button">Add New Topic</a>

                <h3>Topics List</h3>
                <?php if (!empty($topics)): ?>
                    <table class="widefat fixed">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($topics as $topic): ?>
                                <tr>
                                    <td><?php echo $topic->ID; ?></td>
                                    <td><?php echo esc_html($topic->post_title); ?></td>
                                    <td><a href="<?php echo get_edit_post_link($topic->ID); ?>">Edit</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No topics found.</p>
                <?php endif; ?>
            </div>

            <div class="bms-card1">
                <h2><i class="dashicons dashicons-format-status"></i> Questions</h2>
                <p>Manage questions associated with your content.</p>
                <a href="<?php echo admin_url('edit.php?post_type=question'); ?>" class="button button-primary">Manage Questions</a>
                <a href="<?php echo admin_url('post-new.php?post_type=question'); ?>" class="button">Add New Question</a>

                <h3>Questions List</h3>
                <?php if (!empty($questions)): ?>
                    <table class="widefat fixed">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Title</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($questions as $question): ?>
                                <tr>
                                    <td><?php echo $question->ID; ?></td>
                                    <td><?php echo esc_html($question->post_title); ?></td>
                                    <td><a href="<?php echo get_edit_post_link($question->ID); ?>">Edit</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No questions found.</p>
                <?php endif; ?>
            </div>
        </div>

        <style>
            .bms-dashboard-cards {
                display: flex;
                justify-content: space-between;
                flex-wrap: wrap;
            }
            .bms-card {
                background: #fff;
                border: 1px solid #ddd;
                padding: 20px;
                border-radius: 4px;
                width: 30%; /* Adjust width to fit three cards in one row */
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                margin-bottom: 20px;
            }
            .bms-card h2 {
                margin: 0 0 10px;
            }
            .bms-card .button {
                margin-top: 10px;
                display: block;
            }
            .widefat {
                margin-top: 20px;
            }
            
                        .bms-dashboard-cards {
                display: flex;
                justify-content: space-between;
                flex-wrap: wrap;
            }
            .bms-card1 {
                background: #fff;
                border: 1px solid #ddd;
                padding: 20px;
                border-radius: 4px;
                width: 100%; /* Adjust width to fit three cards in one row */
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                margin-bottom: 20px;
            }
            .bms-card1 h2 {
                margin: 0 0 10px;
            }
            .bms-card1 .button {
                margin-top: 10px;
                display: block;
            }
            .widefat {
                margin-top: 20px;
            }

        </style>
    </div>
    <?php
        // Add the import section if needed
    if (isset($_GET['imported']) && $_GET['imported'] === 'true') {
        echo '<div class="updated"><p>Books imported successfully!</p></div>';
    }
}


function bms_import_books() {
    if (isset($_POST['import_books']) && check_admin_referer('bms_import_books_nonce')) {
        // Handle file upload
        if (!empty($_FILES['book_csv']['tmp_name'])) {
            // Read the CSV file
            $file = $_FILES['book_csv']['tmp_name'];
            if (($handle = fopen($file, 'r')) !== FALSE) {
                while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
                    // Assuming the first column is the title
                    $title = sanitize_text_field($data[0]);
                    
                    // Create a new book post
                    $new_book = array(
                        'post_title' => $title,
                        'post_type' => 'book',
                        'post_status' => 'publish',
                    );
                    wp_insert_post($new_book);
                }
                fclose($handle);
                // Redirect to avoid resubmission
                wp_redirect(admin_url('admin.php?page=bms&imported=true'));
                exit;
            }
        }
    }
}
function bms_display_import_form() {
    ?>
    <div class="wrap">
        <h1>Import Books</h1>
        <form method="post" enctype="multipart/form-data">
            <?php wp_nonce_field('bms_import_books_nonce'); ?>
            <p>Upload a CSV file:</p>
            <input type="file" name="book_csv" accept=".csv" required>
            <p><input type="submit" name="import_books" class="button button-primary" value="Import Books"></p>
        </form>
    </div>
    <?php
}


// Hide Custom Post Menu
function bms_hide_custom_post_type_menus() {
    remove_menu_page('edit.php?post_type=book');
    remove_menu_page('edit.php?post_type=chapter');
    remove_menu_page('edit.php?post_type=topic');
    remove_menu_page('edit.php?post_type=question');
}
add_action('admin_menu', 'bms_hide_custom_post_type_menus');


