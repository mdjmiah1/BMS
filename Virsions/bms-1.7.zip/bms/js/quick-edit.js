jQuery(document).ready(function($) {
    // Add inline event listener for quick edit
    function set_quick_edit_fields(post_id) {
        var $edit_row = $('#edit-' + post_id);
        
        // Fetch associated book and chapter for the post
        var book_id = $('#post-' + post_id).find('.column-associated_book').data('book-id');
        var chapter_id = $('#post-' + post_id).find('.column-associated_chapter').data('chapter-id');

        // Set the value of the select fields in Quick Edit
        $edit_row.find('select[name="quick_edit_associated_book"]').val(book_id);
        $edit_row.find('select[name="quick_edit_associated_chapter"]').val(chapter_id);
    }

    // Bind the quick edit event
    $('a.editinline').on('click', function() {
        var post_id = $(this).closest('tr').attr('id').replace('post-', '');
        set_quick_edit_fields(post_id);
    });
});
