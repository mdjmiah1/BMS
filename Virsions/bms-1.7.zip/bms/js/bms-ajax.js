jQuery(document).ready(function($) {
    $('#search_form').on('submit', function(e) {
        e.preventDefault(); // Prevent normal form submission

        var searchTerm = $('#search_term').val();
        var collectionId = $('#collection_id').val();
        var itemUrl = $('#item_url').val();

        $.ajax({
            url: bms_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'bms_fetch_items',
                search_term: searchTerm,
                collection_id: collectionId,
                item_url: itemUrl,
            },
            success: function(response) {
                $('#ajax_results').html(response);
            },
            error: function() {
                $('#ajax_results').html('<p>An error occurred. Please try again.</p>');
            }
        });
    });
});
