<?php
get_header(); // Include the header



// Start the loop to display the single book content
if ( have_posts() ) :
    while ( have_posts() ) : the_post();
        $book_id = get_the_ID();
        ?>
        <div class="book-container">
            <div class="book-sidebar">
                <?php
                // Display associated chapters
                $associated_chapters = get_posts(array(
                    'post_type' => 'chapter',
                    'meta_key' => '_associated_book',
                    'meta_value' => $book_id,
                    'posts_per_page' => -1,
                    'orderby' => 'title',
                    'order' => 'ASC',
                ));

                // Preload all topics for the book and organize them by chapter
                $associated_topics = get_posts(array(
                    'post_type' => 'topic',
                    'meta_key' => '_associated_book_for_topic',
                    'meta_value' => $book_id,
                    'posts_per_page' => -1,
                    'orderby' => 'title',
                    'order' => 'ASC',
                ));

                // Group topics by chapter
                $topics_by_chapter = array();
                foreach ( $associated_topics as $topic ) {
                    $chapter_id = get_post_meta($topic->ID, '_associated_chapter', true);
                    if ($chapter_id) {
                        $topics_by_chapter[$chapter_id][] = $topic;
                    } else {
                        $topics_by_chapter['no_chapter'][] = $topic;
                    }
                }

                if ( $associated_chapters ) : ?>
                    <h2>Table of Contents</h2>
                    <ul class="toc">
                        <?php foreach ( $associated_chapters as $chapter ) : ?>
                            <li>
                                <h3 class="chapter-title">
                                    <a href="<?php echo get_permalink( $chapter->ID ); ?>">
                                        <?php echo esc_html( $chapter->post_title ); ?>
                                    </a>
                                </h3>
                                <?php if ( isset($topics_by_chapter[$chapter->ID]) ) : ?>
                                    <ul class="topics-list">
                                        <?php foreach ( $topics_by_chapter[$chapter->ID] as $topic ) : ?>
                                            <li>
                                                <a href="<?php echo get_permalink( $topic->ID ); ?>">
                                                    <?php echo esc_html( $topic->post_title ); ?>
                                                </a>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php else : ?>
                                    <p>No topics associated with this chapter.</p>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>

                <!-- If no chapters, display topics directly -->
                <?php if ( isset($topics_by_chapter['no_chapter']) ) : ?>
                    <h2>Topics</h2>
                    <ul class="topics-list">
                        <?php foreach ( $topics_by_chapter['no_chapter'] as $topic ) : ?>
                            <li>
                                <a href="<?php echo get_permalink( $topic->ID ); ?>">
                                    <?php echo esc_html( $topic->post_title ); ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else : ?>
                    <p>No topics associated with this book.</p>
                <?php endif; ?>
            </div>

            <div class="book-content content">
                <h1><i class="fa-solid fa-book-open"></i> <?php the_title(); ?></h1>

                <!-- Breadcrumbs -->
                <?php bms_breadcrumbs(); ?>

                <p class="book-meta">
                    <span class="book-author">
                        Author: 
                        <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>">
                            <?php echo get_the_author(); ?>
                        </a>
                    </span> |
                    <span class="book-date">Created: <?php echo get_the_date(); ?></span> | 
                    

                </p>

                <div class="book-description">
                    <?php the_content(); ?>
                </div>

                <!-- Display custom fields in a table -->
                <div class="book-details">
                    <h2>Book Details</h2>
                    <table class="book-details-table">
                        <tbody>
                            <?php
                            // Retrieve custom field values
                            $book_name = get_the_title();
                            $isbn = get_post_meta($book_id, '_bms_book_isbn', true);
                            $publisher = get_post_meta($book_id, '_bms_book_publisher', true);
                            $author = get_post_meta($book_id, '_bms_book_author', true);
                            $page_count = get_post_meta($book_id, '_bms_book_page_count', true);
                            $publish_date = get_post_meta($book_id, '_bms_book_publish_date', true);
                            $file_size = get_post_meta($book_id, '_bms_book_file_size', true);
                            $url = get_post_meta($book_id, '_bms_book_url', true);
                            $archive = get_post_meta($book_id, '_bms_book_archive', true);
                            // Display the book name
                            echo '<tr><td><strong>Book Name:</strong></td><td>' . esc_html($book_name) . '</td></tr>';
                            // Display each custom field if not empty
                            if (!empty($author)) {
                                echo '<tr><td><strong>Author:</strong></td><td>' . esc_html($author) . '</td></tr>';
                            }
                            if (!empty($publisher)) {
                                echo '<tr><td><strong>Publisher:</strong></td><td>' . esc_html($publisher) . '</td></tr>';
                            }
                            if (!empty($page_count)) {
                                echo '<tr><td><strong>Page Count:</strong></td><td>' . esc_html($page_count) . '</td></tr>';
                            }
                            if (!empty($publish_date)) {
                                echo '<tr><td><strong>Publish Date:</strong></td><td>' . esc_html($publish_date) . '</td></tr>';
                            }
                            if (!empty($file_size)) {
                                echo '<tr><td><strong>File Size:</strong></td><td>' . esc_html($file_size) . ' MB</td></tr>';
                            }
                            if (!empty($isbn)) {
                                echo '<tr><td><strong>ISBN:</strong></td><td>' . esc_html($isbn) . '</td></tr>';
                            }
                            if (!empty($url)) {
                                echo '<tr><td><strong>Download URL:</strong></td><td><a href="' . esc_url($url) . '" target="_blank">Download PDF</a></td></tr>';
                            }
                            if (!empty($archive)) {
                                echo '<tr><td><strong>Archive URL:</strong></td><td><a href="https://archive.org/details/' . esc_html($archive) . '" target="_blank">Archive URL</a> | <a href="https://book.pdfforest.in/textbook/?ocaid=' . esc_html($archive) . '" target="_blank">Download PDF</a></td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
               <!-- Display structured data (Schema.org) -->
               
                <!-- Display comments section -->
                <div class="book-comments">
                    <?php
                    // Display comments if enabled
                    if ( comments_open() || get_comments_number() ) :
                        comments_template();
                    endif;
                    ?>
                </div>
            </div>
        </div>
            <script>
      function convertMarkdown() {
        const markdownText = document.getElementById('markdown').value;
        const htmlContent = marked(markdownText);
        document.getElementById('content').innerHTML = htmlContent;
      }
    </script>
        <style>

        </style>
        <?php
        
    endwhile;
endif;

get_footer(); // Include the footer
