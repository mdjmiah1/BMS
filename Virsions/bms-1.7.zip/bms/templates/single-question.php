<?php
get_header(); // Include the header

// Start the loop to display the single question content
if ( have_posts() ) :
    while ( have_posts() ) : the_post();
        $question_id = get_the_ID();
        ?>
        <div class="bms-container">
            <div class="bms-sidebar">
                <?php
                // Display associated book
                $associated_book = get_post_meta($question_id, '_associated_book_for_question', true);
                if ( $associated_book ) :
                    $book = get_post($associated_book);
                    ?>
                    <h2>Associated Book</h2>
                    <p>
                        <a href="<?php echo get_permalink($book->ID); ?>">
                            <?php echo esc_html($book->post_title); ?>
                        </a>
                    </p>
                <?php else : ?>
                    <p>No associated book.</p>
                <?php endif; ?>

                <!-- Display associated chapter -->
                <?php
                $associated_chapter = get_post_meta($question_id, '_associated_chapter_for_question', true);
                if ( $associated_chapter ) :
                    $chapter = get_post($associated_chapter);
                    ?>
                    <h2>Associated Chapter</h2>
                    <p>
                        <a href="<?php echo get_permalink($chapter->ID); ?>">
                            <?php echo esc_html($chapter->post_title); ?>
                        </a>
                    </p>
                <?php else : ?>
                    <p>No associated chapter.</p>
                <?php endif; ?>

                <!-- Display associated topic -->
                <?php
                $associated_topic = get_post_meta($question_id, '_associated_topic_for_question', true);
                if ( $associated_topic ) :
                    $topic = get_post($associated_topic);
                    ?>
                    <h2>Associated Topic</h2>
                    <p>
                        <a href="<?php echo get_permalink($topic->ID); ?>">
                            <?php echo esc_html($topic->post_title); ?>
                        </a>
                    </p>
                <?php else : ?>
                    <p>No associated topic.</p>
                <?php endif; ?>

            </div>

            <div class="bms-content content">
                <h1><i class="fa-solid fa-question-circle"></i> <?php the_title(); ?></h1>
                <!-- Breadcrumbs -->
                <?php bms_breadcrumbs(); ?>

                <p class="bms-meta">
                    <span class="bms-author">
                        Author: 
                        <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>">
                            <?php echo get_the_author(); ?>
                        </a>
                    </span> |
                    <span class="bms-date">Date: <?php echo get_the_date(); ?></span>
                </p>
                
                <div class="bms-description">
                    <span class="bms-date"><h3><strong> Answer </strong><i class="fa-solid fa-circle-check" style="color: #63E6BE;"></i></h3></span>
                    <?php the_content(); ?>
                </div>

                <!-- Display similar questions -->
                <div class="similar-item">
                    <h2>Similar Questions</h2>
                    <?php
                    // Query for similar questions based on tags or categories
                    $similar_questions = get_posts(array(
                        'post_type' => 'question',
                        'numberposts' => 5,
                        'post__not_in' => array($question_id), // Exclude the current question
                        'orderby' => 'rand', // Randomize results
                        'posts_per_page' => 5
                    ));

                    if ( $similar_questions ) : ?>
                        <ul class="similar-item-list">
                            <?php foreach ( $similar_questions as $similar_question ) : ?>
                                <li>
                                    <a href="<?php echo get_permalink( $similar_question->ID ); ?>">
                                        <?php echo esc_html( $similar_question->post_title ); ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else : ?>
                        <p>No similar questions found.</p>
                    <?php endif; ?>
                </div>

                <!-- Display comments section -->
                <div class="bms-comments">
                    <?php
                    // Display comments if enabled
                    if ( comments_open() || get_comments_number() ) :
                        comments_template();
                    endif;
                    ?>
                </div>
            </div>
        </div>
        <?php
        
    endwhile;
endif;

get_footer(); // Include the footer
