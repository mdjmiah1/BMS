=== Book Management System ===
Contributors: MdjMiah
Tags: books, chapters, topics, custom post types, metadata
Requires at least: 5.0
Tested up to: 6.0
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

The Book Management System plugin allows users to manage books, chapters, topics, and associated questions seamlessly. This plugin supports custom post types and provides a user-friendly interface to organize and display book-related content effectively.

== Features ==

* Custom post types for Books, Chapters, Topics, and Questions.
* Ability to associate Chapters and Topics with Books.
* Metadata fields for additional book details (author, publish date, page count, file size, URLs).
* SEO-friendly breadcrumbs for easy navigation.
* Schema markup for enhanced search visibility.
* AJAX-powered filtering for quick content retrieval.
* Fully responsive and compatible with modern WordPress themes.

== Installation ==

1. Upload the `book-management-system` directory to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Use the Book Management System menu to add and manage your books, chapters, topics, and questions.

== Frequently Asked Questions ==

= What are the custom post types created by this plugin? =
This plugin creates custom post types for Books, Chapters, Topics, and Questions.

= Can I associate chapters and topics with a book? =
Yes, the plugin allows you to associate chapters and topics with books through custom metadata fields.

= Is there any support available for this plugin? =
For support, please create an issue in the [GitHub repository](your-repository-url).

== Screenshots ==

1. Dashboard of the Book Management System.
2. Manage Books, Chapters, and Topics.
3. Single Book view with associated chapters and topics.

== Changelog ==
= 1.6.0
* New: Added new function display all items with pagination
= 1.5.0
* New: added new function Item import from internet archive with id
= 1.2.0 =
* New: Added functionality for admin separation and folder organization.
* Update: Fixed issue with breadcrumbs display.
* Improvement: Optimized the layout for single book pages.

= 1.1.0 =
* New: Added support for questions and meta fields.
* Fix: Resolved a bug in topic display.

= 1.0.0 =
* Initial release.



= 1.0 =
* Initial release of the Book Management System plugin.

== Upgrade Notice ==

= 1.0 =
* Initial version.

== License ==

This plugin is licensed under the GPLv2 or later.


== Upgrade Notice ==

= 1.1 =
* New features added. [Download here](https://github.com/yourusername/your-plugin/releases/tag/1.1).