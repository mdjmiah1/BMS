<?php








// canonical_url-functions
function bms_add_canonical_url() {
    if ( is_singular('book') || is_singular('chapter') || is_singular('topic') || is_singular('question') ) {
        echo '<link rel="canonical" href="' . esc_url( get_permalink() ) . '">';
    }
}
add_action('wp_head', 'bms_add_canonical_url');

// In breadcrumbs
function bms_breadcrumbs() {
    $separator = ' > ';
    $home_title = 'Home';
    
    echo '<div class="bms-breadcrumbs">';
    echo '<a href="' . home_url() . '">' . $home_title . '</a>' . $separator;

    if (is_single()) {
        $post_type = get_post_type();

        // Add breadcrumb for the "Book" post type
        if ($post_type === 'book') {
            echo '<a href="' . get_post_type_archive_link('book') . '">Books</a>' . $separator;
        }

        // Add breadcrumb for the "Chapter" post type
        if ($post_type === 'chapter') {
            // Get the associated book (if any) to link back to the book
            $associated_book_id = get_post_meta(get_the_ID(), '_associated_book', true);
            if ($associated_book_id) {
                echo '<a href="' . get_permalink($associated_book_id) . '">' . get_the_title($associated_book_id) . '</a>' . $separator;
            }
            echo '<a href="' . get_post_type_archive_link('chapter') . '">Chapters</a>' . $separator;
        }

        // Add breadcrumb for the "Topic" post type
        if ($post_type === 'topic') {
            // Get the associated chapter and book (if any)
            $associated_chapter_id = get_post_meta(get_the_ID(), '_associated_chapter', true);
            $associated_book_id = get_post_meta(get_the_ID(), '_associated_book_for_topic', true);

            if ($associated_book_id) {
                echo '<a href="' . get_permalink($associated_book_id) . '">' . get_the_title($associated_book_id) . '</a>' . $separator;
            }

            if ($associated_chapter_id) {
                echo '<a href="' . get_permalink($associated_chapter_id) . '">' . get_the_title($associated_chapter_id) . '</a>' . $separator;
            }

            echo '<a href="' . get_post_type_archive_link('topic') . '">Topics</a>' . $separator;
        }

        // Add breadcrumb for the "Question" post type
        if ($post_type === 'question') {
            // Get associated book, chapter, and topic for the question
            $associated_book_id = get_post_meta(get_the_ID(), '_associated_book_for_question', true);
            $associated_chapter_id = get_post_meta(get_the_ID(), '_associated_chapter_for_question', true);
            $associated_topic_id = get_post_meta(get_the_ID(), '_associated_topic_for_question', true);

            if ($associated_book_id) {
                echo '<a href="' . get_permalink($associated_book_id) . '">' . get_the_title($associated_book_id) . '</a>' . $separator;
            }

            if ($associated_chapter_id) {
                echo '<a href="' . get_permalink($associated_chapter_id) . '">' . get_the_title($associated_chapter_id) . '</a>' . $separator;
            }

            if ($associated_topic_id) {
                echo '<a href="' . get_permalink($associated_topic_id) . '">' . get_the_title($associated_topic_id) . '</a>' . $separator;
            }

            echo '<a href="' . get_post_type_archive_link('question') . '">Questions</a>' . $separator;
        }

        // Display the current post title
        echo '<span>' . get_the_title() . '</span>';
    }

    echo '</div>';
}
// In bms-functions SEO Metagas
function bms_seo_meta_tags() {
    if ( is_singular('book') || is_singular('chapter') || is_singular('topic') || is_singular('question') ) {
        global $post;
        $meta_description = get_post_meta($post->ID, '_seo_meta_description', true);
        
        if ($meta_description) {
            echo '<meta name="description" content="' . esc_attr($meta_description) . '">';
        } else {
            echo '<meta name="description" content="' . esc_attr( wp_trim_words( get_the_excerpt(), 30 ) ) . '">';
        }
    }
}
add_action('wp_head', 'bms_seo_meta_tags');

// schema_markup for book
function bms_add_schema_markup() {
    if ( is_singular('book') ) {
        global $post;
        echo '<script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "Book",
          "name": "' . esc_html( get_the_title() ) . '",
          "author": {
            "@type": "Person",
            "name": "' . esc_html( get_the_author() ) . '"
          },
          "datePublished": "' . esc_html( get_the_date() ) . '",
          "publisher": "' . get_bloginfo( 'name' ) . '",
          "description": "' . esc_html( wp_trim_words( get_the_excerpt(), 30 ) ) . '",
          "url": "' . get_permalink() . '"
        }
        </script>';
    }
}
add_action('wp_head', 'bms_add_schema_markup');
// schema_markup for Question
function bms_add_question_schema_markup() {
    if ( is_singular('question') ) {
        global $post;
        echo '<script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "Question",
          "name": "' . esc_html( get_the_title() ) . '",
          "text": "' . esc_html( wp_trim_words( get_the_content(), 50 ) ) . '",
          "author": {
            "@type": "Person",
            "name": "' . esc_html( get_the_author() ) . '"
          },
          "dateCreated": "' . esc_html( get_the_date('c') ) . '",
          "url": "' . get_permalink() . '"
        }
        </script>';
    }
}
add_action('wp_head', 'bms_add_question_schema_markup');



// Open Graph Tags for Social Sharing
function bms_add_open_graph_tags() {
    if ( is_singular('book') || is_singular('chapter') || is_singular('topic') || is_singular('question') ) {
        global $post;
        $og_title = get_the_title();
        $og_url = get_permalink();
        $og_description = get_the_excerpt();
        $og_image = get_the_post_thumbnail_url($post->ID, 'full');
        
        echo '<meta property="og:title" content="' . esc_attr( $og_title ) . '">';
        echo '<meta property="og:url" content="' . esc_url( $og_url ) . '">';
        echo '<meta property="og:description" content="' . esc_attr( wp_trim_words($og_description, 30) ) . '">';
        if ($og_image) {
            echo '<meta property="og:image" content="' . esc_url($og_image) . '">';
        }
    }
}
add_action('wp_head', 'bms_add_open_graph_tags');
