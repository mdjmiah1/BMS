jQuery(document).ready(function($) {
    // Listen for form submission
    $('form#bms_import_form').on('submit', function(e) {
        e.preventDefault(); // Prevent default form submission

        var search_term = $('#search_term').val();
        var collection_id = $('#collection_id').val();
        var item_url = $('#item_url').val();
        var paged = $('#paged').val(); // Optional for pagination
        
        // Show loading spinner (optional)
        $('#bms-loader').show();

        // Perform the AJAX request
        $.ajax({
            url: bms_ajax_object.ajax_url,
            method: 'POST',
            data: {
                action: 'bms_import_books', // Custom AJAX action
                search_term: search_term,
                collection_id: collection_id,
                item_url: item_url,
                paged: paged // Optional for pagination
            },
            success: function(response) {
                // Hide loading spinner (optional)
                $('#bms-loader').hide();

                // Update the table with results
                $('#bms-results').html(response); // Where results are updated
            },
            error: function() {
                $('#bms-loader').hide();
                alert('Failed to load data. Please try again.');
            }
        });
    });
});
