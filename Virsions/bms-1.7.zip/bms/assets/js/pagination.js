jQuery(document).ready(function($) {
    $(document).on('click', '.pagination-link', function(e) {
        e.preventDefault();
        const page = $(this).data('page');
        const search_term = $('#search_term').val();
        const collection_id = $('#collection_id').val();
        const item_url = $('#item_url').val();

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'bms_fetch_items',
                page: page,
                search_term: search_term,
                collection_id: collection_id,
                item_url: item_url,
            },
            success: function(data) {
                $('#items-table tbody').html(data); // Update table body with new items
            }
        });
    });
});
