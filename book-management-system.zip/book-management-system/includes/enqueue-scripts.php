<?php
function bms_enqueue_admin_scripts($hook) {
    // Enqueue Select2 only on post edit and new post pages
    if (in_array($hook, array('post.php', 'post-new.php'))) {
        wp_enqueue_style('select2-css', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css');
        wp_enqueue_script('select2-js', 'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js', array('jquery'), null, true);
        
        // Initialize Select2 for dropdowns
        wp_add_inline_script('select2-js', '
            jQuery(document).ready(function($) {
                $(".bms-select2").select2();
            });
        ');
    }
}

function bms_include_custom_template($template) {
    // Check for custom templates for each post type
    if (is_singular('book')) {
        $plugin_template = plugin_dir_path(__FILE__) . '../templates/single-book.php';
        if (file_exists($plugin_template)) {
            return $plugin_template;
        }
    }

    if (is_singular('chapter')) {
        $plugin_template = plugin_dir_path(__FILE__) . '../templates/single-chapter.php';
        if (file_exists($plugin_template)) {
            return $plugin_template;
        }
    }

    if (is_singular('topic')) {
        $plugin_template = plugin_dir_path(__FILE__) . '../templates/single-topic.php';
        if (file_exists($plugin_template)) {
            return $plugin_template;
        }
    }

    // Add custom template logic for "question"
    if (is_singular('question')) {
        $plugin_template = plugin_dir_path(__FILE__) . '../templates/single-question.php';
        if (file_exists($plugin_template)) {
            return $plugin_template;
        }
    }

    return $template;
}

function bms_enqueue_styles() {
    // Enqueue styles only for specific post types on the front-end
    if (is_singular(array('book', 'chapter', 'topic', 'question'))) {
        wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css', array(), null);
        wp_enqueue_style('bms-plugin-styles', plugin_dir_url(__FILE__) . '../css/styless.css');
    }
}


function bms_enqueue_meta_box_styles() {
    echo '<style>
        #bms_book_details .form-row {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        #bms_book_details .form-item {
            width: 48%; /* Two items per row with some margin */
            margin-bottom: 2px;
        }

        #bms_book_details label {
            font-weight: bold;
            display: block;
            margin-bottom: 5px;
        }

        #bms_book_details input[type="text"],
        #bms_book_details input[type="number"],
        #bms_book_details input[type="date"],
        #bms_book_details input[type="url"] {
            width: 100%;
            padding-left: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
        }

        /* Mobile responsive */
        @media (max-width: 768px) {
            #bms_book_details .form-item {
                width: 100%; /* One item per row on tablets */
            }
        }

        @media (max-width: 480px) {
            #bms_book_details .form-item {
                width: 100%; /* One item per row on mobile */
            }
        }
    </style>';
}
add_action('admin_head', 'bms_enqueue_meta_box_styles');
