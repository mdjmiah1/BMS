<?php
// Function to generate content using AI
function bms_generate_content_with_ai($title, $post_type) {
    $api_key = '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';  // Your API key
    $api_url = 'https://api.example.com/generate';  // Replace with the actual API endpoint

    // Prepare the request
    $response = wp_remote_post($api_url, array(
        'body' => json_encode(array(
            'title' => $title,
            'post_type' => $post_type,
        )),
        'headers' => array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $api_key,
        ),
    ));

    if (is_wp_error($response)) {
        return 'Error generating content';
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    return isset($data['content']) ? $data['content'] : 'No content generated';
}

