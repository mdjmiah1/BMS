jQuery(document).ready(function($) {
    $('#sidebar-toggle').on('click', function() {
        $('#book-sidebar').toggleClass('hidden');
        $('.book-content').toggleClass('shifted');
    });
});
