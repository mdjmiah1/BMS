<?php
get_header(); // Include the header

// Start the loop to display the single chapter content
if ( have_posts() ) :
    while ( have_posts() ) : the_post();
        $chapter_id = get_the_ID();
        $associated_book_id = get_post_meta( $chapter_id, '_associated_book', true );
        
        // Get the associated book
        $associated_book = get_post( $associated_book_id );
        ?>
        <div class="book-container">
            <div class="book-sidebar">
                <?php if ( $associated_book ) : ?>
                    <!-- Display the associated book's name -->
                    <h2><i class="fa-solid fa-book-open"></i> <a href="<?php echo get_permalink( $associated_book->ID ); ?>">
                            <?php echo esc_html( $associated_book->post_title ); ?>
                        </a></h2>
                    

                    <?php
                    // Display chapters associated with the book
                    $book_associated_chapters = get_posts(array(
                        'post_type' => 'chapter',
                        'meta_key' => '_associated_book',
                        'meta_value' => $associated_book->ID,
                        'posts_per_page' => -1,
                        'orderby' => 'title',
                        'order' => 'ASC',
                    ));

                    if ( $book_associated_chapters ) : ?>
                        <h3>Book's Chapters</h3>
                        <ul class="toc">
                            <?php foreach ( $book_associated_chapters as $book_chapter ) : ?>
                                <li>
                                    <a href="<?php echo get_permalink( $book_chapter->ID ); ?>">
                                        <?php echo esc_html( $book_chapter->post_title ); ?>
                                    </a>
                                    <?php
                                    // Display topics associated with this chapter
                                    $associated_topics = get_posts(array(
                                        'post_type' => 'topic',
                                        'meta_key' => '_associated_chapter',
                                        'meta_value' => $book_chapter->ID,
                                        'posts_per_page' => -1,
                                        'orderby' => 'title',
                                        'order' => 'ASC',
                                    ));

                                    if ( $associated_topics ) : ?>
                                        <ul class="topics-list">
                                            <?php foreach ( $associated_topics as $topic ) : ?>
                                                <li>
                                                    <a href="<?php echo get_permalink( $topic->ID ); ?>">
                                                        <?php echo esc_html( $topic->post_title ); ?>
                                                    </a>
                                                </li>
                                            <?php endforeach; ?>
                                        </ul>
                                    <?php else : ?>
                                        <p>No topics associated with this chapter.</p>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else : ?>
                        <p>No chapters associated with this book.</p>
                    <?php endif; ?>
                <?php else : ?>
                    <p>No associated book found.</p>
                <?php endif; ?>
            </div>

            <div class="book-content content">
                <h1><i class="fa-solid fa-book-open"></i> <?php the_title(); ?></h1>
                <?php bms_breadcrumbs(); ?>
                <p class="book-meta">
                    <span class="book-author">
                        Author: 
                        <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>">
                            <?php echo get_the_author(); ?>
                        </a>
                    </span> |
                    <span class="book-date">Published Date: <?php echo get_the_date(); ?></span>
                </p>
                <div class="book-description">
                    <?php the_content(); ?>
                </div>

                <!-- Display comments section -->
                <div class="book-comments">
                    <?php
                    // Display comments
                    if ( comments_open() || get_comments_number() ) :
                        comments_template();
                    endif;
                    ?>
                </div>
            </div>
        </div>
        <?php
        
    endwhile;
endif;

get_footer(); // Include the footer
?>
