<?php
get_header(); // Include the header

// Start the loop to display the single topic content
if ( have_posts() ) :
    while ( have_posts() ) : the_post();
        $topic_id = get_the_ID();
        $associated_chapter_id = get_post_meta( $topic_id, '_associated_chapter', true );

        // Check for the associated chapter
        $associated_chapter = $associated_chapter_id ? get_post( $associated_chapter_id ) : null;
        
        // Get the associated book (via the chapter's association if exists, otherwise via the topic's direct association)
        if ( $associated_chapter ) {
            $associated_book_id = get_post_meta( $associated_chapter->ID, '_associated_book', true );
        } else {
            $associated_book_id = get_post_meta( $topic_id, '_associated_book_for_topic', true );
        }

        $associated_book = $associated_book_id ? get_post( $associated_book_id ) : null;
        ?>
        <div class="book-container">
            <div class="book-sidebar">
                <?php if ( $associated_book ) : ?>
                    <!-- Display the associated book's name -->
                    <h2>Associated Book</h2>
                    <p>
                        <a href="<?php echo get_permalink( $associated_book->ID ); ?>">
                            <?php echo esc_html( $associated_book->post_title ); ?>
                        </a>
                    </p>

                    <?php if ( $associated_chapter ) : ?>
                        <!-- Display the associated chapter's name -->
                        <h3>Associated Chapter</h3>
                        <p>
                            <a href="<?php echo get_permalink( $associated_chapter->ID ); ?>">
                                <?php echo esc_html( $associated_chapter->post_title ); ?>
                            </a>
                        </p>

                        <?php
                        // Display other topics associated with this chapter
                        $other_associated_topics = get_posts(array(
                            'post_type' => 'topic',
                            'meta_key' => '_associated_chapter',
                            'meta_value' => $associated_chapter->ID,
                            'posts_per_page' => -1,
                            'orderby' => 'title',
                            'order' => 'ASC',
                        ));

                        if ( $other_associated_topics && count( $other_associated_topics ) > 1 ) : ?>
                            <h4>Other Topics in This Chapter</h4>
                            <ul class="toc">
                                <?php foreach ( $other_associated_topics as $topic ) : 
                                    // Skip current topic
                                    if ( $topic->ID == $topic_id ) continue;
                                ?>
                                    <li>
                                        <a href="<?php echo get_permalink( $topic->ID ); ?>">
                                            <?php echo esc_html( $topic->post_title ); ?>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    <?php else : ?>
                        <!-- If no chapter is associated, display topics associated with the book -->
                        <h3>Associated Topics</h3>
                        <?php
                        $associated_topics = get_posts(array(
                            'post_type' => 'topic',
                            'meta_key' => '_associated_book_for_topic',
                            'meta_value' => $associated_book->ID,
                            'posts_per_page' => -1,
                            'orderby' => 'title',
                            'order' => 'ASC',
                        ));

                        if ( $associated_topics ) : ?>
                            <ul class="toc">
                                <?php foreach ( $associated_topics as $topic ) : ?>
                                    <li>
                                        <a href="<?php echo get_permalink( $topic->ID ); ?>">
                                            <?php echo esc_html( $topic->post_title ); ?>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php else : ?>
                            <p>No topics associated with this book.</p>
                        <?php endif; ?>
                    <?php endif; ?>

                <?php else : ?>
                    <p>No associated book found.</p>
                <?php endif; ?>
            </div>

            <div class="book-content content">
                <h1><i class="fa-solid fa-book-open"></i> <?php the_title(); ?></h1>
                <?php bms_breadcrumbs(); ?>
                <p class="book-meta">
                    <span class="book-author">
                        Author: 
                        <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>">
                            <?php echo get_the_author(); ?>
                        </a>
                    </span> |
                    <span class="book-date">Published Date: <?php echo get_the_date(); ?></span>
                </p>
                <div class="book-description">
                    <?php the_content(); ?>
                </div>

                <!-- Display comments section -->
                <div class="book-comments">
                    <?php
                    // Display comments
                    if ( comments_open() || get_comments_number() ) :
                        comments_template();
                    endif;
                    ?>
                </div>
            </div>
        </div>
        <?php
        
    endwhile;
endif;

get_footer(); // Include the footer
?>
