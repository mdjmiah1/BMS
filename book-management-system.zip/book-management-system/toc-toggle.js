jQuery(document).ready(function($) {
    var tocContent = $('#toc-content');
    var tocButton = $('#toc-toggle');

    // Initially, TOC is open
    tocContent.addClass('open');
    tocButton.html('<i class="fas fa-caret-up"></i> Hide TOC');

    tocButton.click(function() {
        tocContent.toggleClass('open');
        if (tocContent.hasClass('open')) {
            tocButton.html('<i class="fas fa-caret-up"></i> Hide TOC');
        } else {
            tocButton.html('<i class="fas fa-caret-down"></i> Show TOC');
        }
    });
});
